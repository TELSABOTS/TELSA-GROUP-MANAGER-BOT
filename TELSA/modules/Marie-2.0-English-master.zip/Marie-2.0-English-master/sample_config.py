START_IMG = "https://telegra.ph/file/f7968acc8d3d70ec40cbc.jpg"
