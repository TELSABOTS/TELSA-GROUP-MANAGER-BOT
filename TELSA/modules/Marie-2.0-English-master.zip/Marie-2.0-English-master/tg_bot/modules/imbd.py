__help__ = """
- /imdb <film/series> : Find IMDB rating of a film/series
"""

__mod_name__ = "IMDB"
